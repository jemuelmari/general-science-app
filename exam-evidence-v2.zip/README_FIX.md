# Exam Evidence v2.0.0 — Ayos sa hindi pagtugma ng evidence at actual exam

## Mga file (palitan sa repo)
- `teacher/evidence.js`   — bagong generator (HTML/print + Word)
- `teacher/evidence.html` — bagong page (Term, Assessment, Section, Student, Paper size, Preview/Print/Word/Reload)

Walang binago sa quiz-engine, randomize, store o Code.gs. Hindi na kailangang i-link ang `evidence-print.css`
(may sariling @media print ang page).

## Ano ang mali dati
Hinahanap ang tanong sa KASALUKUYANG `student/termN/assessments/*.json` gamit ang `questionId` → `originalIndex` → `index`,
nang walang beripikasyon. Kapag nabago ang bank pagkatapos mag-exam ng bata (content revision, competency tagging,
revert/regenerate, nagbago ang ID o ayos), ibang tanong at choices ang lumalabas sa evidence, kaya lumilipat ang "mali".

## Ano ang ginawa
1. Ang naka-save na `itemResults` ng estudyante (given, expected, correct, order) ang source of truth.
2. Ang tanong sa bank ay ginagamit LAMANG kung tugma: ang `expected` = tamang sagot ng tanong, ang `given` ay isa sa choices,
   at tugma ang competency/bloom kung naka-save. Hahanapin muna by id → originalIndex → index → buong bank (kung iisa lang ang tugma).
3. Kapag walang tugma, hindi manghuhula: ipapakita ang naka-save na sagot ng estudyante at may paliwanag sa evidence.
4. Ang item numbers ay ayon sa ayos na nakita ng estudyante (Set A/B), at ipinapakita ang Set sa info table.
5. Ang mali/tama ay laging galing sa naka-save na `correct` flag, ang parehong ginamit ng exam.
